$(document).ready(function(){
    
    $('#btnModal').click(function(){
        $('#myModal').modal();
    });


})